# IDQR Project

## Запуск:
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```